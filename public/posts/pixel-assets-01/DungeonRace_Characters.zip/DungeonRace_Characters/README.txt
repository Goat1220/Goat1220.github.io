DungeonRace Pixel Assets
========================

Top-down pixel art made for the game DungeonRace.
탑다운 픽셀아트 게임 DungeonRace 를 만들면서 만든 도트 그림입니다.
AI(PixelLab)로 만들고 손으로 고쳤습니다.

Folders / 폴더
- Characters/<Class>/   6 classes: Barbarian, Fighter, Mage, Cleric, Ranger, Bard
    56x56 px. walk_<dir>_0..7, attack_<dir>_0..7, idle_<dir>, sit_<south|west|east>
- Monsters/<Name>/      11 monsters
    Goblin, Zombie, Skeleton (44x44), Ogre (92x92), GiantSpider (96x96)
    Bosses (72x72): GoblinBoss, OrcCaptain, OrcChief, TrollLord, BlackKnight, DeathKnight
    idle_<dir>, attack_<dir>_<n>  (attack frame counts differ per monster and direction)
- Dungeon/<Theme>/      4 themes: GoblinCave, Dungeon, Labyrinth, AncientTemple
    floor, wall_n, wall_e, wall_w, wall_ne, wall_nw : 24x42 canvas, one cell is 16x12 px
    Props/floor_XX, Props/wall_XX : decorations, trimmed to their own size
- Effects/<Name>/       frame_0..n
    Slash, Smash (64x64), Hit, HolyLight, MagicBolt, MagicBurst, Notes (48x48), Arrow (32x32)
- UI/                   menu backgrounds and card pictures (180 px wide screens)

<dir> = south (down), west (left), east (right), north (up)
Every PNG has a transparent background (UI backgrounds are opaque).

Unity
- Texture Type: Sprite (2D and UI), Pixels Per Unit: 32
- Filter Mode: Point (no filter), Compression: None

License: see LICENSE.txt (credit required / 출처 표기 필수)
